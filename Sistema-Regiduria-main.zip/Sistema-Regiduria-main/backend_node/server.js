const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors()); // Permite que tu HTML llame a este servidor
app.use(bodyParser.json()); // Permite recibir JSON

// 1. Conexión a Base de Datos (Igual que en PHP pero en JS)
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'sistema_regiduria'
});

db.connect(err => {
    if (err) {
        console.error('Error conectando a la BD:', err);
        return;
    }
    console.log('Conectado a MySQL exitosamente');
});

// ---------------------------------------------------------
// 2. TUS APIs (Endpoints)
// ---------------------------------------------------------

// API: Guardar Escuela (Reemplaza a api/escuelas.php)
app.post('/api/escuelas', (req, res) => {
    const { nivel, cct, nombre_escuela, director, password } = req.body;

    // Mapeo rápido de nivel a ID
    const nivelesMap = { 'Preescolar': 1, 'Primaria': 2, 'Secundaria': 3, 'Medio Superior': 4, 'Superior': 5 };
    const nivel_id = nivelesMap[nivel] || 1;

    const sql = `INSERT INTO usuarios (cct_usuario, password, nombre_escuela, nombre_director, nivel_id, rol) 
                 VALUES (?, ?, ?, ?, ?, 'escuela')`;

    db.query(sql, [cct, password, nombre_escuela, director, nivel_id], (err, result) => {
        if (err) {
            // Si hay error (ej. CCT duplicado)
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ success: false, message: 'Error: La clave CCT ya existe.' });
            }
            return res.status(500).json({ success: false, message: 'Error en base de datos.' });
        }
        
        res.json({ success: true, message: 'Escuela registrada correctamente' });
    });
});

// API: Leer Escuelas (Para llenar la tabla)
app.get('/api/escuelas', (req, res) => {
    // Hacemos un JOIN para traer el nombre del nivel (y el color)
    const sql = `
        SELECT u.*, n.nombre as nombre_nivel, n.color_mapa 
        FROM usuarios u 
        JOIN niveles_educativos n ON u.nivel_id = n.id 
        WHERE u.rol = 'escuela'
    `;
    
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// API: Login (Reemplaza login.php)
app.post('/api/login', (req, res) => {
    const { usuario, password } = req.body;
    
    const sql = 'SELECT * FROM usuarios WHERE cct_usuario = ? AND password = ?';
    db.query(sql, [usuario, password], (err, results) => {
        if (err) return res.status(500).json({ success: false, message: 'Error de servidor' });
        
        if (results.length > 0) {
            const user = results[0];
            res.json({ 
                success: true, 
                user: { id: user.id, nombre: user.nombre_escuela, rol: user.rol } 
            });
        } else {
            res.json({ success: false, message: 'Credenciales incorrectas' });
        }
    });
});

// ---------------------------------------------------------

// Iniciar servidor en puerto 3000
app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});